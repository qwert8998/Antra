﻿using System;

namespace Exercise2
{
    public class Arithmetic
    {
        int Input1, Input2;
        public Arithmetic(int a, int b)
        {
            Input1 = a;
            Input2 = b;
        }
        public void Addition ()
        {
            Console.WriteLine(Input1 + Input2);
        }

        public void Subtraction()
        {
            Console.WriteLine(Input1 - Input2);
        }

        public void Multiplication() 
        {
            Console.WriteLine(Input1 * Input2);
        }

        public void Division()
        {
            Console.WriteLine(Input1 / Input2);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int Input1, Input2, Choice;
            Console.WriteLine("Enter First Number:");
            Input1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Second Number:");
            Input2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Choose the Arithmetic (Please input the number):");
            Console.WriteLine("1. Additional");
            Console.WriteLine("2. Subtraction");
            Console.WriteLine("3. Multiplication");
            Console.WriteLine("4. Division");
            Choice = int.Parse(Console.ReadLine());
            var calculate = new Arithmetic(Input1,Input2);
            switch(Choice)
            {
                case 1: calculate.Addition(); break;
                case 2: calculate.Subtraction(); break;
                case 3: calculate.Multiplication(); break;
                case 4: calculate.Division(); break;
                default: Console.WriteLine("Enter the wrong number!"); break;
            }
            //Console.WriteLine("Hello World!");
        }
    }
}
