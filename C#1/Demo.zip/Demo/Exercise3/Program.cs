﻿using System;

namespace Exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            Console.WriteLine("Enter a string:");
            input = Console.ReadLine();
            Console.Write("The reverse string: ");
            Console.WriteLine(Reverse(input));
            //Console.WriteLine("Hello World!");
        }
        static string Reverse(string str)
        {
            var c = str.ToCharArray();
            Array.Reverse(c);

            return new string(c);
        }
    }
}
