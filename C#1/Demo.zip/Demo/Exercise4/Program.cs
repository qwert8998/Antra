﻿using System;

namespace Exercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            int start, end, num;

            Console.Write("Input starting number of range: ");
            start = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input ending number of range : ");
            end = Convert.ToInt32(Console.ReadLine());

            for (num = start; num <= end; num++)
            {
                int temp, sum, r;
                temp = num;
                sum = 0;

                while (temp != 0)
                {
                    r = temp % 10;
                    temp = temp / 10;
                    sum = sum + (r * r * r);
                }
                if (sum == num)
                    Console.WriteLine("{0} ", num);
            }
        }
    }
}
