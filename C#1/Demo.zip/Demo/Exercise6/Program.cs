﻿using System;

namespace Exercise6
{
    class Program
    {
        static void Main(string[] args)
        {
            int num_row;
            Console.WriteLine("Enter number of rows");
            num_row = Convert.ToInt32(Console.ReadLine());
            PrintDiamond(num_row);
        }

        static void PrintDiamond(int num)
        {
            int i, j;
            for (i = 0; i <= num; i++)
            {
                for (j = 1; j <= num - i; j++)
                    Console.Write(" ");
                for (j = 1; j <= 2 * i - 1; j++)
                    Console.Write("*");
                Console.Write("\n");
            }

            for (i = num - 1; i >= 1; i--)
            {
                for (j = 1; j <= num - i; j++)
                    Console.Write(" ");
                for (j = 1; j <= 2 * i - 1; j++)
                    Console.Write("*");
                Console.Write("\n");
            }
        }
    }
}
