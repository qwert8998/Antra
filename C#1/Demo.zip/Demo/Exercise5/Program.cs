﻿using System;

namespace Exercise5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num_row;
            Console.WriteLine("Enter the Number of Rows:");
            num_row = Convert.ToInt32(Console.ReadLine());
            PrintTree(num_row);
        }

        static void PrintTree(int num)
        {
            int total_item, level = 1, cnt = 0;
            total_item = ((1 + num) * num) / 2;

            for(int i=0; i< total_item; i++)
            {
                cnt++;
                if (i % 2 == 0)
                    Console.Write("1");
                else
                    Console.Write("0");
                if(cnt >= level)
                {
                    Console.Write("\n");
                    level++;
                    cnt = 0;
                }
            }
        }
    }
}
