﻿using System;

namespace Exercise7
{
    class Program
    {
        static int initial = 1000;
        static void Main(string[] args)
        {
            string pin;
            int action;
            bool open = true;
            Console.WriteLine("Enter your Pin Number:");
            pin = Console.ReadLine();
            if (string.IsNullOrEmpty(pin))
            {
                Console.WriteLine("Input Empty! Please restart the Console!");
                return;
            }

            while (open)
            {
                action = ShowATM();
                switch (action)
                {
                    case 1: Balance(); break;
                    case 2: Withdraw(); break;
                    case 3: Deposite(); break;
                    case 4: open = false; break;
                    default: Console.WriteLine("Please input a valid number!"); break;
                }
            }
            return;
        }

        static int ShowATM()
        {
            Console.WriteLine("********Welcome to ATM Service**************");
            Console.WriteLine();
            Console.WriteLine("1. Check Balance");
            Console.WriteLine();
            Console.WriteLine("2. Withdraw Cash");
            Console.WriteLine();
            Console.WriteLine("3. Deposit Cash");
            Console.WriteLine();
            Console.WriteLine("4. Quit");
            Console.WriteLine();
            Console.WriteLine("*********************************************");
            Console.WriteLine("Enter your choice:");

            return Convert.ToInt32(Console.ReadLine());
        }

        static void Balance()
        {
            Console.Write("YOU’RE BALANCE IN Rs: ");
            Console.WriteLine(initial);
        }

        static void Withdraw()
        {
            int amount;
            Console.WriteLine("Please input your withdraw amount:");
            amount = Convert.ToInt32(Console.ReadLine());
            if(amount > initial)
            {
                Console.WriteLine("The Withdraw Amount is more than your Balance");
            }
            else
            {
                initial -= amount;
                Console.WriteLine("Success");
            }
        }

        static void Deposite()
        {
            int amount;
            Console.WriteLine("Please input your Deposite amount:");
            amount = Convert.ToInt32(Console.ReadLine());
            initial += amount;
            Console.WriteLine("Success");
        }
    }
}
