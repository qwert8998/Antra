﻿//1.
let salaries = {
    John: 100,
    Ann: 160,
    Peter: 130
};

function SumSalary() {
    let r = salaries.John + salaries.Ann + salaries.Peter;
    console.log(r);
};
SumSalary();

//2.
let menu = {
    width: 200,
    height: 300,
    title: "My menu"
};
function multiplyNumeric(obj) {
    obj.width = obj.width * 2;
    obj.height = obj.height * 2;
};
multiplyNumeric(menu);
console.log(menu);

//3.
function checkEmailId(str) {
    var test = /\S+@\S+\.\S+/;
    return test.test(str);
};
console.log(checkEmailId('asdfg@gmail.com')); //true
console.log(checkEmailId('asdfg@.com')); //false
console.log(checkEmailId('asdfggmail.com')); //false

//4.
function truncate(str, maxlength) {
    if (str.length <= maxlength)
        console.log(str);
    else
    {
        str = str.substring(0, maxlength - 1);
        str += '...';
        console.log(str);
    }
};
truncate("What I'd like to tell on this topic is:", 20);// = "What I'd like to te…"
truncate("Hi everyone!", 20);// = "Hi everyone!"

//5.
function print(arr) {
    var i;
    let ans = '';
    for (i = 0; i < arr.length; i++)
    {
        if (i != 0)
            ans += ','; 
        ans += arr[i];
    }
    console.log(ans);
};
function replaceMiddle(arr,input) {
    let i = arr.length;
    i =  (i-1) / 2;
    arr[i] = input;
};
let arr = new Array('James', 'Brennie');
print(arr);

arr.push('Robert');
print(arr);

replaceMiddle(arr, 'Calvin');
print(arr);

arr.shift();
print(arr);

arr.unshift('Regal');
arr.unshift('Rose');
print(arr);

//6.
function verifycard(cardnumber) {
    var i, last;
    let sum = 0;
    for (i = 0; i < cardnumber.length; i++)
    {
        if (i != cardnumber.length - 1) {
            sum += parseInt(cardnumber.substr(i, 1)) * 2;
        }
        else
            last = parseInt(cardnumber.substr(i,1));
    }

    return (sum%10) == last;
};

function verifyprex(cardnumber, banned) {
    var i;
    for (i = 0; i < banned.length; i++)
    {
        if (banned[i] == cardnumber.substring(0, banned[i].length))
            return false;
    }
    return true;
}

function validateCards(listcard, bannedlist) {
    var i;
    var ans = new Array();
    for (i = 0; i < listcard.length; i++)
    {
        var card = listcard[i];
        var obj = {
            Card: card,
            IsValid: verifycard(card),
            IsAllowed: verifyprex(card, bannedlist)
        };
        ans.push(obj);
    }
    return ans;
};

let listcard = ['6724843711060148', '6724843711060148', '6724843711060147'];
let pre = ['11', '3434', '67453', '9'];
let ans = validateCards(listcard, pre);
console.log(ans);

//7.
function checkEmailId1(strin) {
    var test = /^[a-z]{1,6}_?\d{0,4}@hackerrank+\.com$/;
    return test.test(strin);
};

console.log(checkEmailId1('julia@hackerrank.com'));
console.log(checkEmailId1('julia_@hackerrank.com'));
console.log(checkEmailId1('julia_0@hackerrank.com'));
console.log(checkEmailId1('julia0_@hackerrank.com'));
console.log(checkEmailId1('julia@gmail.com'));