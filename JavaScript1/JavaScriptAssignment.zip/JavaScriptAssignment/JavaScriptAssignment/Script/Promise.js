﻿let p1 = fetch("https://jsonplaceholder.typicode.com/posts").then(function (response) {
    return response.json();
});

p1.then(function (data) {
    let tbody = document.querySelector("tbody");
    tbody.innerHTML = "";
    let len = data.length;
    for (let i = 0; i < len; i++) {
        let tr = "<tr><td>" + data[i].id + "</td><td>" + data[i].title + "</td><td>" + data[i].body + "</td></tr>";
        tbody.innerHTML += tr;
    }
}).catch(function (e) {
    console.log(e);
    });

/*
Since the url in the docx is not work. I used the url that used in class. 
*/