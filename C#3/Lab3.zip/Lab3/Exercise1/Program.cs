﻿using System;

namespace Exercise1
{
    abstract class Shape1
    {

        protected float R, L, B;

        //Abstract methods can have only declarations
        public abstract float Area();
        public abstract float Circumference();

    }

    class Circle : Shape1
    {
        public void SetValue()
        {
            Console.Write("Please input the Radius of Circle: ");
            R = Convert.ToInt32(Console.ReadLine());
        }

        public override float Area()
        {
            return R * R * (float)3.14;
        }

        public override float Circumference()
        {
            return (2 * R) * (float)3.14;
        }
    }

    class Rectangle : Shape1
    {
        public void SetValue()
        {
            Console.Write("Please input the Length of Rectangle: ");
            L = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please input the Breadth of Rectangle: ");
           B = Convert.ToInt32(Console.ReadLine());
        }
        public override float Area()
        {
            return L * B;
        }

        public override float Circumference()
        {
            return (L + B) * 2;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var obj1 = new Circle();
            obj1.SetValue();
            Calculate(obj1);

            var obj2 = new Rectangle();
            obj2.SetValue();
            Calculate(obj2);

        }

        public static void Calculate(Shape1 S)
        {

            Console.WriteLine("Area : {0}", S.Area());
            Console.WriteLine("Circumference : {0}", S.Circumference());

        }

    }
}
