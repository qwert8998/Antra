﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace Exercise5
{
    public class ComplexNumber
    {
        public int Real { get; set; }
        public int Imaginary { get; set; }

        public ComplexNumber(int a, int b)
        {
            Real = a;
            Imaginary = b;
        }

        public new string ToString()
        {
            return $"({Real},{Imaginary})";
        }

        public double GetMagnitude()
        {
            var complex = new Complex(Real, Imaginary);
            return Complex.Abs(complex);
        }

        public void SetImaginary(int b)
        {
            Imaginary = b;
        }

        public void Add (ComplexNumber cm2)
        {
            Real += cm2.Real;
            Imaginary += cm2.Imaginary;
        }
    }
}
