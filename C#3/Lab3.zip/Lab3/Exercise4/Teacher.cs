﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    public class Teacher: Person
    {
        private string subject;
        public void Explain()
        {
            Console.WriteLine("Explaination begins");
        }
    }
}
