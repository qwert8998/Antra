﻿using System;

namespace Exercise4
{
    class Program
    {
        static void Main(string[] args)
        {
            var obj1 = new Person();

            var obj2 = new Student();
            obj2.SetAge(21);
            obj2.showAge();

            var obj3 = new Teacher();
            obj3.SetAge(30);
            obj3.Explain();
        }
    }
}
