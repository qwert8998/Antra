﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    public class Student: Person
    {
        public void GoToClasses()
        {
            Console.WriteLine("I am going to class.");
        }

        public void showAge()
        {
            Console.WriteLine($"My age is: {Age} years old");
        }
    }
}
