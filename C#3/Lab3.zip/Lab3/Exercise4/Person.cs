﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise4
{
    public class Person
    {
        public int Age { get; set; }
        public Person()
        {
            Console.WriteLine("Hello");
        }

        public void SetAge(int age)
        {
            Age = age;
        }
    }
}
