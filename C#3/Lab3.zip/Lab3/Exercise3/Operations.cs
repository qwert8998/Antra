﻿using Exercise3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exercise3
{
    public class HouseholdAccounts
    {
        static List<Record> list = new List<Record>();

        public void Add()
        {
            string  des, cate;
            int amount,date, num;
            Console.Write("Please input Number:");
            num = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please input Date:");
            date = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please input Description:");
            des = Console.ReadLine();

            Console.Write("Please input Category:");
            cate = Console.ReadLine();

            Console.Write("Please input Amount:");
            amount = Convert.ToInt32(Console.ReadLine());

            list.Add(new Record { 
                Number = num,
                Date = date,
                Description = des,
                Category = cate,
                Amount = amount
            });

            Console.WriteLine("Add Successfully\n");
        }

        public void ShowAll()
        {
            string cate;
            int start, end;
            Console.Write("Please input a Category: ");
            cate = Console.ReadLine();

            Console.Write("Please input start:");
            start = Convert.ToInt32(Console.ReadLine());

            Console.Write("Please input end:");
            end = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Number\t Date\t Description(Category)\t Amount");
            foreach (var item in list)
            {
                if(item.Category == cate)
                {
                    if(item.Date <= end && item.Date >= start)
                    {
                        Console.WriteLine($"{item.Number}\t {item.Date}\t {item.Description}({item.Category})\t {item.Amount}");
                    }
                }
            }
            Console.WriteLine();
        }

        public void SearchContext()
        {
            string str;
            Console.Write("Please input your specific context: ");
            str = Console.ReadLine().ToLower();

            Console.WriteLine("Number\t Date\t Description");
            foreach(var item in list)
            {
                if(item.Category.ToLower().Contains(str) || item.Description.ToLower().Contains(str))
                {
                    Console.WriteLine($"{item.Number}\t {item.Date}\t {item.Description.Substring(0,6)}");
                }
            }
            Console.WriteLine();
        }

        public void Modify()
        {
            int num;
            Record r = null;
            Console.Write("Please input User Number:");
            num = Convert.ToInt32(Console.ReadLine());
            r = FindByNumber(num);

            if (r == null)
                Console.WriteLine("Please input a correct User Number!");
            else
            {
                Console.Write("Modify Number: ");
                num = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine($"{r.Number}\t {r.Date}\t {r.Description}({r.Category})\t {r.Amount}");
                Console.WriteLine("Cannot be modified!");
            }

            Console.WriteLine();
        }

        public void Delete()
        {
            int num;
            Record r = null;
            Console.Write("Please input User Number:");
            num = Convert.ToInt32(Console.ReadLine());
            r = FindByNumber(num);

            if (r == null)
                Console.WriteLine("Please input the correct number!");
            else
            {
                Console.WriteLine($"We will delete the user number: {num}");
                Console.WriteLine($"{r.Number}\t {r.Date}\t {r.Description}({r.Category})\t {r.Amount}");
                Console.WriteLine("Please press Enter");
                Console.ReadLine();
                list.Remove(r);
            }

            Console.WriteLine("Delete Successfully\n");
        }

        public void Sort()
        {
            var order = list.OrderBy(x => x.Date).OrderBy(x => x.Description);
            Console.WriteLine("Number\t Date\t Description(Category)\t Amount");
            foreach (var item in order)
            {
                Console.WriteLine($"{item.Number}\t {item.Date}\t {item.Description}({item.Category})\t {item.Amount}");
            }
        }

        public void Normalize()
        {
            Console.WriteLine("Number\t Date\t Description(Category)\t Amount");
            foreach (var item in list)
            {
                var des = item.Description.Replace(" ",string.Empty);
                des = des.Substring(0, 1) + des[1..].ToLower();
                Console.WriteLine($"{item.Number}\t {item.Date}\t {des}({item.Category})\t {item.Amount}");
            }
        }

        public Record FindByNumber(int num)
        {
            Record r = null;
            foreach (var item in list)
            {
                if (item.Number == num)
                    r = item;
            }
            return r;
        }
    }
}
