﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise3.Model
{
    public class Record
    {
        public int Number { get; set; }
        public int Date { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public int Amount { get; set; }
    }
}
