﻿using System;

namespace Exercise3
{
    class Program
    {
        static HouseholdAccounts accounts = new HouseholdAccounts();
        static void Main(string[] args)
        {
            bool con = true;
            while(con)
            {
                con = Print();
            }
        }

        static bool Print()
        {
            bool conti = true;
            int choice;
            var arr = Enum.GetNames(typeof(Operation));
            var value = (int[])Enum.GetValues(typeof(Operation));

            for(int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine($"{value[i]}. {arr[i]}");
            }
            Console.Write("Please input your choice: ");
            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case (int)Operation.Add:
                    accounts.Add();break;
                case (int)Operation.ShowExpenses:
                    accounts.ShowAll(); break;
                case (int)Operation.Modify:
                    accounts.Modify(); break;
                case (int)Operation.Delete:
                    accounts.Delete(); break;
                case (int)Operation.Sort:
                    accounts.Sort(); break;
                case (int)Operation.Normalize:
                    accounts.Normalize(); break;
                case (int)Operation.Exit:
                    conti = false;break;
                default:
                    Console.WriteLine("Please input a correct number!");break;
            }

            return conti;
        }
    }


    enum Operation
    {
        Add = 1,
        ShowExpenses,
        Modify,
        Delete,
        Sort,
        Normalize,
        Exit
    }
}
