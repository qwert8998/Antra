﻿using ADO.NET.Data.Model;
using ADO.NET.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ADO.NET
{
    public class PrintOrderedMinions
    {
        MinionsRepository minions;

        public PrintOrderedMinions()
        {
            minions = new MinionsRepository();
        }

        public void Run()
        {
            var list = minions.GetAll().ToList();
            Print(list);
            OrderList(list);
        }

        private void OrderList(List<Minions> data)
        {
            int left = 0, cnt = 0;
            int right = data.Count() - 1;
            Console.WriteLine("After order: ");
            while(left <= right)
            {
                Console.WriteLine($"{data[left].Id}\t {data[left].Name}");
                left++;
                if(left < right)
                {
                    Console.WriteLine($"{data[right].Id}\t {data[right].Name}");
                    right--;
                }
            }
        }

        private void Print(List<Minions> data)
        {
            Console.WriteLine("Before order: ");
            foreach(var item in data)
            {
                Console.WriteLine($"{item.Id}\t {item.Name}");
            }
        }
    }
}
