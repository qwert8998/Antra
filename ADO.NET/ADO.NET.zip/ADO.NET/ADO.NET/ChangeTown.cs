﻿using ADO.NET.Data.Model;
using ADO.NET.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADO.NET
{
    public class ChangeTown
    {
        CountryRepository country;
        TownRepository towns;

        public ChangeTown()
        {
            country = new CountryRepository();
            towns = new TownRepository();
        }

        public void Run()
        {
            var list = country.GetAll();
            Console.WriteLine("List All Countries: ");
            foreach(var item in list)
            {
                Console.WriteLine($"{item.Id}. {item.Name}");
            }
            Console.Write("Please input a Country Name: ");
            var countryname = Console.ReadLine();
            ChangeTownName(countryname);
        }

        private void ChangeTownName(string name)
        {
            var coun = country.GetByName(name);
            var message = string.Empty;
            if(coun == null)
            {
                Console.WriteLine("No town names were affected.");
            }
            else
            {
                var list = towns.GetByCountryCode(coun.Id).ToList();
                if(list.Count() > 0)
                {
                    int cnt = 0;
                    message += "[";
                    foreach(var item in list)
                    {
                        cnt++;
                        item.Name = item.Name.ToUpper();
                        towns.Update(item);
                        message += item.Name + ",";
                    }
                    message = message.Substring(0, message.Length - 1) + "]";
                    Console.WriteLine($"{cnt} town names were affected.\n {message}");
                }
                else
                {
                    Console.WriteLine("No town names were affected.");
                }
            }
        }

    }
}
