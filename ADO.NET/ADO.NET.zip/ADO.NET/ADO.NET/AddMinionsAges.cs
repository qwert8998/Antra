﻿using ADO.NET.Data.Model;
using ADO.NET.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADO.NET
{
    public class AddMinionsAges
    {
        MinionsRepository minions;

        public AddMinionsAges()
        {
            minions = new MinionsRepository();
        }

        public void Run()
        {
            var list = minions.GetAll().ToList();
            Print(list);
            AskUsers(list);
        }

        private void AskUsers(List<Minions> data)
        {
            Console.WriteLine("Please input Ids of Minions (separate by space for each minion): ");
            var numlist = Console.ReadLine().Split(' ');

            foreach(var num in numlist)
            {
                AddOne(data, Convert.ToInt32(num));
            }
            Print(data);
        }

        private void AddOne (List<Minions> data, int Id)
        {
            var update = data.Where(x => x.Id == Id).FirstOrDefault();
            update.Age += 1;
            minions.Update(update);
        }

        public void Print(List<Minions> data)
        {
            Console.WriteLine($"Id\t Name\t\t Age");
            foreach(var item in data)
            {
                Console.WriteLine($"{item.Id}\t {item.Name.Trim()}\t\t {item.Age}");
            }
        }
    }
}
