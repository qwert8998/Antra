﻿using ADO.NET.Data.Model;
using ADO.NET.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ADO.NET
{
    public class DeleteVillain
    {
        VillainsRepository villains;
        MinionsVillainsRepository minionsVillains;

        public DeleteVillain()
        {
            villains = new VillainsRepository();
            minionsVillains = new MinionsVillainsRepository();
        }

        public void Run()
        {
            Console.Write("Please enter a Villain Id: ");
            int id = Convert.ToInt32(Console.ReadLine());
            DeleteProcess(id);
        }

        private void DeleteProcess(int id)
        {
            var villain = villains.GetById(id);
            if(villain == null)
            {
                Console.WriteLine("No such villain was found.");
            }
            else
            {
                var minionlist = minionsVillains.GetByVillainId(villain.Id).ToList();
                if(DeleteMinions(minionlist))
                {
                    try
                    {
                        villains.GetById(villain.Id);
                        Console.WriteLine($"{villain.Name} was Deleted.");
                        Console.WriteLine($"{minionlist.Count()} minions were released");
                    }
                    catch(Exception e)
                    {
                        Console.WriteLine($"Something goes wrong on deleting villain! Messgae: {e.Message}");
                    }
                }
            }
        }

        private bool DeleteMinions (List<MinionsVillains> data)
        {
            try
            {
                foreach(var item in data)
                {
                    minionsVillains.DeleteByIds(item.VillainId,item.MinionId);
                }
                return true;
            }
            catch(Exception e)
            {
                Console.WriteLine($"Something goes wrong on deleting minions_villains! Message: {e.Message}");
                return false;
            }
        }
    }
}
