﻿using ADO.NET.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ADO.NET
{
    public class Villain_Names
    {
        VillainsRepository villains;
        MinionsVillainsRepository minionsVillainsRepository;

        public Villain_Names()
        {
            villains = new VillainsRepository();
            minionsVillainsRepository = new MinionsVillainsRepository();
        }

        public void PrintOutput()
        {
            var dic = CountMinions();
            foreach(var item in dic)
            {
                if (item.Value > 3)
                    Console.WriteLine($"{item.Key} - {item.Value}");
            }
        }

        private Dictionary<string, int> CountMinions()
        {
            var result = new Dictionary<string, int>();
            var villainslist = villains.GetAll();
            var belongs = minionsVillainsRepository.GetAll();

            foreach(var item in villainslist)
            {
                int cnt = belongs.Where(x => x.VillainId == item.Id).Count();
                result.Add(item.Name,cnt);
            }

            return result;
        }
    }
}
