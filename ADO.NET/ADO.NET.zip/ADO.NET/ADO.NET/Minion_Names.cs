﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using ADO.NET.Data.Repository;
using ADO.NET.Data.Model;

namespace ADO.NET
{
    public class Minion_Names
    {
        MinionsVillainsRepository minionsVillains;
        MinionsRepository minions;
        VillainsRepository villains;

        public Minion_Names()
        {
            minionsVillains = new MinionsVillainsRepository();
            minions = new MinionsRepository();
            villains = new VillainsRepository();
        }

        public void Run()
        {
            int id;
            Console.Write("Please input a villain id: ");
            id = Convert.ToInt32(Console.ReadLine());
            PrintOutput(id);
        }

        private void PrintOutput(int id)
        {
            var villain = villains.GetById(id);
            if(villain != null)
            {
                var minionlist = GetMinionsByVillainId(id);
                int cnt = 0;

                Console.WriteLine($"Villain: {villain.Name}");
                if(minionlist.Count() > 0)
                {
                    foreach (var item in minionlist)
                    {
                        cnt++;
                        Console.WriteLine($"{cnt}. {item.Name} {item.Age}");
                    }
                }
                else
                {
                    Console.WriteLine("(no minions)");
                }
            }
            else
            {
                Console.WriteLine($"No villain with ID {id} exists in the database.");
            }
        }

        private IEnumerable<Minions> GetMinionsByVillainId(int id)
        {
            var minionlist = minions.GetAll();
            var list = minionsVillains.GetAll().Where(x => x.VillainId == id);

            var result = new List<Minions>();

            foreach(var item in list)
            {
                result.Add(minionlist.Where(x => x.Id == item.MinionId).FirstOrDefault());
            }

            return result.OrderBy(x => x.Name);
        }
    }
}
