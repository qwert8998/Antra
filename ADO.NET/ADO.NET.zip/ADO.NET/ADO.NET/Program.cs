﻿using System;

namespace ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            //var exercise1 = new Villain_Names();
            //exercise1.PrintOutput();

            //var exercise2 = new Minion_Names();
            //exercise2.Run();

            //var exercise3 = new Add_Minion();
            //exercise3.Run();

            //var exercise4 = new ChangeTown();
            //exercise4.Run();

            //var exercise5 = new DeleteVillain();
            //exercise5.Run();

            //var exercise6 = new PrintOrderedMinions();
            //exercise6.Run();

            //var exercise7 = new AddMinionsAges();
            //exercise7.Run();

            var exercise8 = new AddByProcedure();
            exercise8.Run();
        }
    }
}
