﻿using ADO.NET.Data.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace ADO.NET
{
    public class AddByProcedure
    {
        MinionsRepository minions;
        public AddByProcedure()
        {
            minions = new MinionsRepository();
        }

        public void Run()
        {
            var list = minions.GetAll();
            foreach(var item in list)
            {
                Console.WriteLine($"{item.Id}\t {item.Name}\t\t {item.Age}");
            }
            bool continued = true;
            while (continued)
            {
                continued = AddOne();
            }
        }

        private bool AddOne()
        {
            Console.Write("Input Id of Minion: ");
            var Id = Convert.ToInt32(Console.ReadLine());
            minions.UpdateByProcedure(Id);
            var one = minions.GetById(Id);
            Console.WriteLine($"{one.Name} - {one.Age} years old.");
            Console.Write("To be continued? (y)");
            var ans = Console.ReadLine();
            if (ans.ToLower().Equals("y"))
                return true;
            else
                return false;
        }
    }
}
