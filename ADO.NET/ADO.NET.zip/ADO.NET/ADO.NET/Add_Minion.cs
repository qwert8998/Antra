﻿using ADO.NET.Data.Model;
using ADO.NET.Data.Repository;
using System;

namespace ADO.NET
{
    public class Add_Minion
    {
        TownRepository town;
        MinionsRepository minions;
        VillainsRepository villains;
        MinionsVillainsRepository minionsVillains;

        public Add_Minion()
        {
            town = new TownRepository();
            minions = new MinionsRepository();
            villains = new VillainsRepository();
            minionsVillains = new MinionsVillainsRepository();
        }

        public void Run()
        {
            Console.Write("Please input an Minion <Name> <Age> <Town>: ");
            var info = Console.ReadLine().Split(' ');
            if(info.Length != 3)
            {
                Console.WriteLine("Please enter the correct format!");
            }
            Console.Write("Please input the Villain: ");
            var villain = Console.ReadLine();

            TownCheck(info[2]);
            VillainCheck(villain);
            MinionCheck(info);
            InsertRelationship(villain,info[0]);
        }

        private void InsertRelationship(string villain, string minion)
        {
            var mi = minions.GetByName(minion);
            var vi = villains.GetByName(villain);
            try
            {
                var obj = new MinionsVillains() { 
                    MinionId = mi.Id,
                    VillainId = vi.Id
                };

                minionsVillains.Insert(obj);
                Console.WriteLine($"Successfully added {minion} to be minion of {villain}.");
            }
            catch(Exception e)
            {
                Console.WriteLine($"Something goes wrong on inserting minion_villain! Messgae:{e.Message}");
            }
        }

        private void VillainCheck(string villain)
        {
            if(villains.GetByName(villain) == null)
            {
                var obj = new Villains() { 
                    Name = villain,
                    EvilnessFactorId = 4
                };
                try
                {
                    villains.Insert(obj);
                    Console.WriteLine($"Villain {villain} was added to the database.");
                }
                catch(Exception e)
                {
                    Console.WriteLine($"Something goes wrong on inserting villain! Message:{e.Message}");
                }
            }
        }

        private bool MinionCheck (string[] param)
        {
            try
            {
                if (minions.GetByName(param[0]) == null)
                {
                    var townid = town.GetByName(param[2]);
                    var obj = new Minions()
                    {
                        Name = param[0],
                        Age = Convert.ToInt32(param[1]),
                        TownId = townid.Id
                    };
                    minions.Insert(obj);
                }
                return true;       
            }
            catch(Exception e)
            {
                Console.WriteLine($"Something goes wrong on inserting Minion! Messgae:{e.Message}");
                return false;
            }
        }

        private void TownCheck(string to)
        {
            var obj = town.GetByName(to);
            if(obj == null)
            {
                try
                {
                    obj = new Towns() { 
                        Name = to,
                        CountryCode = 4
                    };
                    town.Insert(obj);

                    Console.WriteLine($"Town {to} was added to the database.");
                }
                catch(Exception e)
                {
                    Console.WriteLine($"Something goes wrong on inserting town! Message:{e.Message}");
                }
            }
        }
    }
}
