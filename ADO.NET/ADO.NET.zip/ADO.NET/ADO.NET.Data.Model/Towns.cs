﻿namespace ADO.NET.Data.Model
{
    public class Towns
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CountryCode { get; set; }
    }
}
