﻿namespace ADO.NET.Data.Model
{
    public class EvilnessFactors
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
