﻿namespace ADO.NET.Data.Model
{
    public class Minions
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int TownId { get; set; }
    }
}
