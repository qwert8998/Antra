﻿namespace ADO.NET.Data.Model
{
    public class Countries
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
