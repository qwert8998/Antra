﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADO.NET.Data.Model
{
    public class Villains
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int EvilnessFactorId { get; set; }
    }
}
