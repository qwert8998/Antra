﻿namespace ADO.NET.Data.Model
{
    public class MinionsVillains
    {
        public int MinionId { get; set; }
        public int VillainId { get; set; }
    }
}
