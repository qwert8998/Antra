﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ADO.NET.Data.Repository
{
    class DBHelper
    {
        IConfigurationBuilder builder;
        public DBHelper()
        {

        }

        public string GetConnectionString()
        {
            builder = new ConfigurationBuilder();
            var root = builder.AddJsonFile("jsconfig1.json").Build();
            string connectionString = root.GetConnectionString("CompanyDB");
            return connectionString;
        }

        public int ExecuteDML(string cmd, Dictionary<string, object> parameters, CommandType cmdType = CommandType.Text)
        {
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand sqlCommand = new SqlCommand();
            try
            {
                sqlConnection.ConnectionString = GetConnectionString();
                sqlConnection.Open();
                sqlCommand.CommandText = cmd;
                sqlCommand.CommandType = cmdType;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        sqlCommand.Parameters.AddWithValue(item.Key, item.Value);
                    }
                }

                sqlCommand.Connection = sqlConnection;
                int result = sqlCommand.ExecuteNonQuery();

                sqlConnection.Close();
                return result;
            }
            catch (Exception ex)
            { }
            finally
            {
                sqlCommand.Dispose();
                sqlConnection.Dispose();
            }
            return 0;
        }

        public DataTable GetData(string cmd, Dictionary<string, object> parameters, CommandType cmdType = CommandType.Text)
        {
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand sqlCommand = new SqlCommand();
            try
            {
                sqlConnection.ConnectionString = GetConnectionString();
                sqlConnection.Open();
                sqlCommand.CommandText = cmd;
                sqlCommand.CommandType = cmdType;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        sqlCommand.Parameters.AddWithValue(item.Key, item.Value);
                    }
                }
                sqlCommand.Connection = sqlConnection;
                SqlDataReader reader = sqlCommand.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                sqlConnection.Close();
                return dt;
            }
            catch (Exception ex)
            { }
            finally
            {
                sqlCommand.Dispose();
                sqlConnection.Dispose();
            }
            return null;
        }
    }
}
