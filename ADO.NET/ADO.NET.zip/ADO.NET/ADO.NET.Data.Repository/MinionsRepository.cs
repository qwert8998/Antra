﻿using ADO.NET.Data.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ADO.NET.Data.Repository
{
    public class MinionsRepository : IRepository<Minions>
    {
        DBHelper _helper;

        public MinionsRepository()
        {
            _helper = new DBHelper();
        }
        public int Delete(int id)
        {
            string statement = "Delete from Minions where id =@id";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@id", id);
            return _helper.ExecuteDML(statement, parametes);
        }

        public IEnumerable<Minions> GetAll()
        {
            string cmd = "Select Id, Name, Age, TownId from Minions";
            DataTable dt = _helper.GetData(cmd, null);
            if (dt != null)
            {
                List<Minions> lstDepartment = new List<Minions>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    Minions d = new Minions
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        Age = Convert.ToInt32(dataRow["Age"]),
                        TownId = Convert.ToInt32(dataRow["TownId"])
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        public Minions GetById(int id)
        {
            string cmd = "Select Id, Name, Age, TownId from Minions where id=@id";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@id", id);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {

                DataRow dataRow = dt.Rows[0];
                Minions d = new Minions
                {
                    Id = Convert.ToInt32(dataRow["Id"]),
                    Name = Convert.ToString(dataRow["Name"]),
                    Age = Convert.ToInt32(dataRow["Age"]),
                    TownId = Convert.ToInt32(dataRow["TownId"])
                };

                return d;
            }
            return null;
        }

        public Minions GetByName(string name)
        {
            string cmd = "Select Id, Name, Age, TownId from Minions where Name=@name";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@name", name);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if(dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Minions d = new Minions
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        Age = Convert.ToInt32(dataRow["Age"]),
                        TownId = Convert.ToInt32(dataRow["TownId"])
                    };

                    return d;
                }
            }
            return null;
        }

        public int Insert(Minions item)
        {
            SqlConnection connection = new SqlConnection(_helper.GetConnectionString());
            connection.Open();

            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = "Insert into Minions values(@name,@age,@town)";
            sqlCommand.Parameters.AddWithValue("@name", item.Name);
            sqlCommand.Parameters.AddWithValue("@age", item.Age);
            sqlCommand.Parameters.AddWithValue("@town", item.TownId);

            sqlCommand.Connection = connection;

            int result = sqlCommand.ExecuteNonQuery();

            connection.Close();
            return result;
        }

        public int Update(Minions item)
        {
            string statement = "Update Villains set Name=@dname, Age=@age, TownId=@town where Id=@id";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@dname", item.Name);
            parametes.Add("@age", item.Age);
            parametes.Add("@town", item.TownId);
            parametes.Add("@id", item.Id);
            return _helper.ExecuteDML(statement, parametes);
        }

        public int UpdateByProcedure(int Id)
        {
            string statement = "usp_GetOlder";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@id", Id);
            return _helper.ExecuteDML(statement, parametes, CommandType.StoredProcedure);
        }
    }
}
