﻿using ADO.NET.Data.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ADO.NET.Data.Repository
{
    public class MinionsVillainsRepository : IRepository<MinionsVillains>
    {
        DBHelper _helper;

        public MinionsVillainsRepository() 
        {
            _helper = new DBHelper();
        }
        public int Delete(int id)
        {
            throw new NotImplementedException();
        }

        public int DeleteByIds(int villainId, int minionId)
        {
            string statement = "Delete from MinionsVillains where MinionId=@mid and VillainId=@vid";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@vid", villainId);
            parametes.Add("@mid", minionId);
            return _helper.ExecuteDML(statement, parametes);
        }

        public IEnumerable<MinionsVillains> GetAll()
        {
            string cmd = "Select MinionId, VillainId from MinionsVillains";
            DataTable dt = _helper.GetData(cmd, null);
            if (dt != null)
            {
                List<MinionsVillains> lstDepartment = new List<MinionsVillains>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    MinionsVillains d = new MinionsVillains
                    {
                        MinionId = Convert.ToInt32(dataRow["MinionId"]),
                        VillainId = Convert.ToInt32(dataRow["VillainId"]),
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        /// <summary>
        /// get data by MinionId
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public MinionsVillains GetById(int id)
        {
            string cmd = "Select MinionId, VillainId from MinionsVillains where MinionId=@id";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@id", id);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {

                DataRow dataRow = dt.Rows[0];
                MinionsVillains d = new MinionsVillains
                {
                    MinionId = Convert.ToInt32(dataRow["MinionId"]),
                    VillainId = Convert.ToInt32(dataRow["VillainId"]),
                };

                return d;
            }
            return null;
        }

        /// <summary>
        /// get data by MinionId/ VillainId
        /// </summary>
        /// <param name="id"></param>
        /// <param name="idName"></param>
        /// <returns></returns>
        public IEnumerable<MinionsVillains> GetByVillainId(int id, string idName = "VillainId")
        {
            string cmd = $"Select MinionId, VillainId from MinionsVillains where {idName}=@id";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@id", id);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {

                List<MinionsVillains> lstDepartment = new List<MinionsVillains>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    MinionsVillains d = new MinionsVillains
                    {
                        MinionId = Convert.ToInt32(dataRow["MinionId"]),
                        VillainId = Convert.ToInt32(dataRow["VillainId"]),
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        public int Insert(MinionsVillains item)
        {
            SqlConnection connection = new SqlConnection(_helper.GetConnectionString());
            connection.Open();

            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = "Insert into MinionsVillains values(@minion,@villain)";
            sqlCommand.Parameters.AddWithValue("@minion", item.MinionId);
            sqlCommand.Parameters.AddWithValue("@villain", item.VillainId);

            sqlCommand.Connection = connection;

            int result = sqlCommand.ExecuteNonQuery();

            connection.Close();
            return result;
        }

        public int Update(MinionsVillains item)
        {
            throw new NotImplementedException();
        }
    }
}
