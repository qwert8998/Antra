﻿using ADO.NET.Data.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ADO.NET.Data.Repository
{
    public class CountryRepository : IRepository<Countries>
    {
        DBHelper _helper;

        public CountryRepository()
        {
            _helper = new DBHelper();
        }
        public int Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Countries> GetAll()
        {
            string cmd = "Select Id, Name from Countries";
            DataTable dt = _helper.GetData(cmd, null);
            if (dt != null)
            {
                List<Countries> lstDepartment = new List<Countries>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    Countries d = new Countries
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"])
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        public Countries GetById(int id)
        {
            string cmd = "Select Id, Name from Countries where id=@id";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@id", id);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if(dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Countries d = new Countries
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"])
                    };

                    return d;
                }
            }
            return null;
        }

        public Countries GetByName(string name)
        {
            string cmd = "Select Id, Name from Countries where Name=@name";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@name", name);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Countries d = new Countries
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"])
                    };

                    return d;
                }
            }
            return null;
        }

        public int Insert(Countries item)
        {
            throw new NotImplementedException();
        }

        public int Update(Countries item)
        {
            throw new NotImplementedException();
        }
    }
}
