﻿using ADO.NET.Data.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ADO.NET.Data.Repository
{
    public class TownRepository : IRepository<Towns>
    {
        DBHelper _helper;

        public TownRepository()
        {
            _helper = new DBHelper();
        }
        public int Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Towns> GetAll()
        {
            string cmd = "Select Id, Name, CountryCode from Towns";
            DataTable dt = _helper.GetData(cmd, null);
            if (dt != null)
            {
                List<Towns> lstDepartment = new List<Towns>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    Towns d = new Towns
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        CountryCode = Convert.ToInt32(dataRow["CountryCode"])
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        public Towns GetById(int id)
        {
            string cmd = "Select Id, Name, CountryCode from Towns where id=@id";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@id", id);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if(dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Towns d = new Towns
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        CountryCode = Convert.ToInt32(dataRow["CountryCode"])
                    };

                    return d;
                }
            }
            return null;
        }

        public IEnumerable<Towns> GetByCountryCode(int code)
        {
            string cmd = "Select Id, Name, CountryCode from Towns where CountryCode=@code";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@code", code);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                List<Towns> lstDepartment = new List<Towns>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    Towns d = new Towns
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        CountryCode = Convert.ToInt32(dataRow["CountryCode"])
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        public Towns GetByName(string name)
        {
            string cmd = "Select Id, Name, CountryCode from Towns where Name=@name";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@name", name);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Towns d = new Towns
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        CountryCode = Convert.ToInt32(dataRow["CountryCode"])
                    };

                    return d;
                }
            }
            return null;
        }

        public int Insert(Towns item)
        {
            SqlConnection connection = new SqlConnection(_helper.GetConnectionString());
            connection.Open();

            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = "Insert into Towns values(@name,@country)";
            sqlCommand.Parameters.AddWithValue("@name", item.Name);
            sqlCommand.Parameters.AddWithValue("@country", item.CountryCode);

            sqlCommand.Connection = connection;

            int result = sqlCommand.ExecuteNonQuery();

            connection.Close();
            return result;
        }

        public int Update(Towns item)
        {
            string statement = "Update Towns set Name=@dname where Id=@id";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@dname", item.Name);
            parametes.Add("@id", item.Id);
            return _helper.ExecuteDML(statement, parametes);
        }
    }
}
