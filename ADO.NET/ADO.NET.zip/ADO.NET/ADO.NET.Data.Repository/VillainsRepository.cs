﻿using ADO.NET.Data.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ADO.NET.Data.Repository
{
    public class VillainsRepository : IRepository<Villains>
    {
        DBHelper _helper;
        public VillainsRepository()
        {
            _helper = new DBHelper();
        }
        public int Delete(int id)
        {
            string statement = "Delete from Villains where id =@id";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@id", id);
            return _helper.ExecuteDML(statement, parametes);
        }

        public IEnumerable<Villains> GetAll()
        {
            string cmd = "Select Id, Name, EvilnessFactorId from Villains";
            DataTable dt = _helper.GetData(cmd, null);
            if (dt != null)
            {
                List<Villains> lstDepartment = new List<Villains>();

                foreach (DataRow dataRow in dt.Rows)
                {
                    Villains d = new Villains
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        EvilnessFactorId = Convert.ToInt32(dataRow["EvilnessFactorId"])
                    };

                    lstDepartment.Add(d);
                }
                return lstDepartment;
            }
            return null;
        }

        public Villains GetById(int id)
        {
            string cmd = "Select Id, Name, EvilnessFactorId from Villains where id=@id";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@id", id);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if(dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Villains d = new Villains
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        EvilnessFactorId = Convert.ToInt32(dataRow["EvilnessFactorId"])
                    };

                    return d;
                }
            }
            return null;
        }

        public Villains GetByName(string name)
        {
            string cmd = "Select Id, Name, EvilnessFactorId from Villains where Name=@name";
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("@name", name);
            DataTable dt = _helper.GetData(cmd, parameters);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    DataRow dataRow = dt.Rows[0];
                    Villains d = new Villains
                    {
                        Id = Convert.ToInt32(dataRow["Id"]),
                        Name = Convert.ToString(dataRow["Name"]),
                        EvilnessFactorId = Convert.ToInt32(dataRow["EvilnessFactorId"])
                    };

                    return d;
                }
            }
            return null;
        }

        public int Insert(Villains item)
        {
            SqlConnection connection = new SqlConnection(_helper.GetConnectionString());
            connection.Open();

            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = "Insert into Villains values(@name,@evilnessFactorId)";
            sqlCommand.Parameters.AddWithValue("@name", item.Name);
            sqlCommand.Parameters.AddWithValue("@evilnessFactorId", item.EvilnessFactorId);

            sqlCommand.Connection = connection;

            int result = sqlCommand.ExecuteNonQuery();

            connection.Close();
            return result;
        }

        public int Update(Villains item)
        {
            string statement = "Update Villains set Name =@dname, EvilnessFactorId =@ef where Id=@id";
            Dictionary<string, object> parametes = new Dictionary<string, object>();
            parametes.Add("@dname", item.Name);
            parametes.Add("@ef", item.EvilnessFactorId);
            parametes.Add("@id", item.Id);
            return _helper.ExecuteDML(statement, parametes);
        }
    }
}
