﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace NewLanguageFeatures
{
    public class Customer
    {

        public int CustomerID { get; private set; }
        public string Name { get; set; }
        public string City { get; set; }

        public Customer(int ID)
        {
            CustomerID = ID;
        }

        public override string ToString()
        {
            return Name + "\t" + City + "\t" + CustomerID;
        }
    }

    class Program
    {
        static void VarTest()
        {
            /*The type of the variable is inferred from its initializer
             *An implicitly typed declaration must include an initializer.
             *var x;  
             *x = new int[] { 1, 2, 3 };
             */

            /*An implicit array initialization expression must specify that an array is 
             * being created and include new[].
             * when using implicitly typed local variables, the initializer cannot be an object 
             * or collection initializer by itself.  
             * It can be a new expression that includes an object or collection initializer.
             var x = { 1, 2, 3 };
             */

            var i = 43;

            var s = "...This is only a test...";

            var numbers = new[] { 4, 9, 16 };

            var complex = new SortedDictionary<string, List<DateTime>>();
            

        }

        static void Main(string[] args)
        {
            //Customer c = new Customer(1)
            //{
            //    Name = "Maria Anders",
            //    City = "Berlin",
            //};

            //Console.WriteLine(c);

            //Exercise1 2 3
            var customers = CreateCustomers();

            Console.WriteLine("Customers:\n");
            foreach (var c in customers)
                Console.WriteLine(c);

            //Exercise4
            var addedCustomers = new List<Customer>
            {
                new Customer(9)  { Name = "Paolo Accorti", City = "Torino" },
                new Customer(10) { Name = "Diego Roel", City = "Madrid" }
            };

            var updatedCustomers = customers.Append(addedCustomers);

            var newCustomer = new Customer(10)
            {
                Name = "Diego Roel",
                City = "Madrid"
            };

            foreach (var c in updatedCustomers)
            {
                if (newCustomer.Compare(c))
                {
                    Console.WriteLine("The new customer was already in the list");
                    break;
                }
            }

            //Console.WriteLine("The new customer was not in the list");

            //Exercise5
            foreach (var c in FindCustomersByCity(customers, "London"))
                Console.WriteLine(c);
            var customerDictionary = new Dictionary<Customer, string>();

            foreach (var c in customers)
                customerDictionary.Add(c, c.Name.Split(' ')[1]);

            var matches = customerDictionary.FilterBy
                (
                    (customer, lastName) => lastName.StartsWith("A")
                );
            //The above line runs the query  
            Console.WriteLine("Number of Matches: {0}", matches.Count);

            //Exercise6
            //Expression<Func<int, bool>> filter = n => (n * 3) < 5;

            //BinaryExpression lt = (BinaryExpression)filter.Body;
            //BinaryExpression mult = (BinaryExpression)lt.Left;
            //ParameterExpression en = (ParameterExpression)mult.Left;
            //ConstantExpression three = (ConstantExpression)mult.Right;
            //ConstantExpression five = (ConstantExpression)lt.Right;

            //Console.WriteLine("({0} ({1} {2} {3}) {4})", lt.NodeType,
            //         mult.NodeType, en.Name, three.Value, five.Value);
            Func<int, int> addOne = n => n + 1;
            Console.WriteLine("Result: {0}", addOne(5));

            Expression<Func<int, int>> addOneExpression = n => n + 1;
            var addOneFunc = addOneExpression.Compile();
            Console.WriteLine("Result: {0}", addOneFunc(5));

            //Exercise7
            Query();

            //Exercise8
            Query8();
        }

        static void Query()
        {
            var stores = CreateStores();
            //foreach (var store in stores.Where(s => s.City == "London"))
            //    Console.WriteLine(store);
            IEnumerable<Store> results = from s in stores
                                         where s.City == "London"
                                         select s;

            foreach (var s in results)
                Console.WriteLine(s);

            var numLondon = stores.Count(s => s.City == "London");
            Console.WriteLine("There are {0} stores in London. ", numLondon);

        }

        static void Query8()
        {
            var results = from c in CreateCustomers()
                          join s in CreateStores() on c.City equals s.City
                          group s by c.Name into g
                          let count = g.Count()
                          orderby count ascending
                          select new { CustomerName = g.Key, Count = g.Count() };

            foreach (var r in results)
                Console.WriteLine("{0}\t{1}", r.CustomerName, r.Count);


        }

        static List<Store> CreateStores()
        {
            return new List<Store>
              {
                new Store { Name = "Jim’s Hardware",    City = "Berlin" },
                new Store { Name = "John’s Books",  City = "London" },
                new Store { Name = "Lisa’s Flowers",    City = "Torino" },
                new Store { Name = "Dana’s Hardware",   City = "London" },
                new Store { Name = "Tim’s Pets",    City = "Portland" },
                new Store { Name = "Scott’s Books",     City = "London" },
                new Store { Name = "Paula’s Cafe",  City = "Marseille" },
              };
        }

        static List<Customer> CreateCustomers()
        {
            return new List<Customer>
            {
                new Customer(1) { Name = "Maria Anders",     City = "Berlin"    },
                new Customer(2) { Name = "Laurence Lebihan", City = "Marseille" },
                new Customer(3) { Name = "Elizabeth Brown",  City = "London"    },
                new Customer(4) { Name = "Ann Devon",        City = "London"    },
                new Customer(5) { Name = "Paolo Accorti",    City = "Torino"    },
                new Customer(6) { Name = "Fran Wilson",      City = "Portland"  },
                new Customer(7) { Name = "Simon Crowther",   City = "London"    },
                new Customer(8) { Name = "Liz Nixon",        City = "Portland"  }
            };
        }

        public static List<Customer> FindCustomersByCity(List<Customer> customers, string city)
        {
            //return customers.FindAll((Customer c) => c.City == city);
            return customers.FindAll(c => c.City == city);
        }

    }
}
