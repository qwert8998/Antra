﻿using System.Collections.Generic;

namespace NewLanguageFeatures
{
    public delegate bool KeyValueFilter<K, V>(K key, V value);
    public static class Extensions
    {
        /// <summary>
        /// This extension method takes in a dictionary and a delegate.  
        /// It then iterates over all of the key value pairs in the dictionary 
        /// and invokes the filter delegate for each.  
        /// If the filter method returns true, then that value is added to a list and returned.  
        /// </summary>
        /// <typeparam name="K"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <param name="items"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public static List<K> FilterBy<K, V>(this Dictionary<K, V> items,KeyValueFilter<K, V> filter)
        {
            var result = new List<K>();

            foreach (KeyValuePair<K, V> element in items)
            {
                if (filter(element.Key, element.Value))
                    result.Add(element.Key);
            }
            return result;
        }

        /// <summary>
        /// Extension methods provide an elegant way to extend types with functionality you develop, 
        /// making the extensions appear to be part of the original types.  
        /// Extension methods enable  new functionality to be added to an already compiled class.  
        /// This includes user created classes as well as .NET classes such as List<T>.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static List<T> Append<T>(this List<T> a, List<T> b)
        {
            var newList = new List<T>(a);
            newList.AddRange(b);
            return newList;
        }

        /// <summary>
        /// Extension methods are only available if declared in a static class and are scoped by the associated namespace.  
        /// They then appear as additional methods on the types that are given by their first parameter.
        /// </summary>
        /// <param name="customer1"></param>
        /// <param name="customer2"></param>
        /// <returns></returns>
        public static bool Compare(this Customer customer1, Customer customer2)
        {
            if (customer1.CustomerID == customer2.CustomerID &&
                customer1.Name == customer2.Name &&
                customer1.City == customer2.City)
            {
                return true;
            }

            return false;
        }
    }
}
