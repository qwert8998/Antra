﻿using System;

namespace Exercise5
{
    class Program
    {
        static void Main(string[] args)
        {
            var obj1 = new Box();
            obj1.setLength(7);
            obj1.setBreadth(10);
            obj1.setHeight(20);
            Console.WriteLine($"The volumn of Box1: {obj1.getVolume()}");

            var obj2 = new Box();
            obj2.setLength(17);
            obj2.setBreadth(2);
            obj2.setHeight(4);
            Console.WriteLine($"The volumn of Box2: {obj2.getVolume()}"); 
            
            var obj3 = new Box();
            obj3.setLength(12);
            obj3.setBreadth(3);
            obj3.setHeight(8);
            Console.WriteLine($"The volumn of Box3: {obj3.getVolume()}");

        }

    }
}
