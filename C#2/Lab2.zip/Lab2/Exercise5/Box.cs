﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise5
{
    public class Box
    {
        double Length;
        double Breadth;
        double Height;

        public double getVolume()
        {
            return Length * Breadth * Height;
        }
        public void setLength(double len)
        {
            Length = len;
        }

        public void setBreadth(double bre)
        {
            Breadth = bre;
        }

        public void setHeight(double hei)
        {
            Height = hei;
        }

    }
}
