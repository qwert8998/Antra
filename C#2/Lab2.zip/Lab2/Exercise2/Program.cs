﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            int size, cnt = 0;
            Console.WriteLine("Please enter the array size:");
            size = Convert.ToInt32(Console.ReadLine());
            var arr = new int[size];

            while(cnt<size)
            {
                Console.Write("Please enter the value:");
                arr[cnt] = Convert.ToInt32(Console.ReadLine());
                cnt++;
                Console.Write("\n");
            }

            Console.WriteLine($"The value occurs the most is: {solution(arr)}");
        }

        static int solution (int[] A)
        {
            var dic = new Dictionary<int, int>();

            for(int i=0; i<A.Length; i++)
            {
                if (dic.ContainsKey(A[i]))
                    dic[A[i]] += 1;
                else
                    dic.Add(A[i],1);
            }

            return dic.OrderByDescending(x => x.Value).FirstOrDefault().Key;
        }
    }
}
