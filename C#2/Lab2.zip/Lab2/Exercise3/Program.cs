﻿using System;

namespace Exercise3
{
    class Program
    {
        static int input1, input2;
        static void Main(string[] args)
        {
            
            bool correct = false;
            while(!correct)
            {
                Console.Write("Please enter the first number (between -10000~10000):");
                input1 = Convert.ToInt32(Console.ReadLine());
                if (input1 > 10000 || input1 < -10000)
                {
                    Console.WriteLine("Please enter the correct number!");
                }
                else
                    correct = true;
            }
            correct = false;

            while (!correct)
            {
                Console.Write("Please enter the second number (between -10000~10000):");
                input2 = Convert.ToInt32(Console.ReadLine());
                if (input2 > 10000 || input2 < -10000 || input2 < input1)
                {
                    Console.WriteLine("Please enter the correct number!");
                }
                else
                    correct = true;
            }

            var sol = new Solution();
            Console.WriteLine($"The number of whole square within the interval[{input1},{input2}] is {sol.solution(input1,input2)}");
        }
    }
}
