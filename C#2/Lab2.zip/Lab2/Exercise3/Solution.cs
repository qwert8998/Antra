﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise3
{
    class Solution
    {
        public int solution(int A, int B)
        {
            int ans = 0;
            int start = (int)Math.Sqrt((double)A);
            int end = (int)Math.Sqrt((double)B);
            Console.WriteLine($"Sqrt(A): {start}, Sqrt(B): {end}");

            if ((start * start) >= A)
                ans += 1;
            if ((end * end) >= B)
                ans -= 1;

            return ans + (end - start);
        }
    }
}
